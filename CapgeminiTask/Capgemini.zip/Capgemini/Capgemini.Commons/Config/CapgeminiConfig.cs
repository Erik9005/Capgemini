﻿namespace Capgemini.Commons.Config
{
    public class CapgeminiConfig
    {
        public string ConnectionString { get; set; }
    }
}